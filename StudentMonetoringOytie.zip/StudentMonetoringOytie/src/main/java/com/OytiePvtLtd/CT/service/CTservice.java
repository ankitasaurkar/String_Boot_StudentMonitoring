package com.OytiePvtLtd.CT.service;

import com.OytiePvtLtd.CT.web.dto.CTregistrationDto;
import com.OytiePvtLtd.CTLogin.model.CTregistration;


public interface CTservice 
{
	static CTregistration save(CTregistrationDto registrationDto) {
		// TODO Auto-generated method stub
		return null;
	}

	CTregistration save(CTregistration registrationDto);
}
