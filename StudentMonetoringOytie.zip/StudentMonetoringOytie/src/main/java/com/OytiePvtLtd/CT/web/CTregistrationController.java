package com.OytiePvtLtd.CT.web;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.OytiePvtLtd.CT.service.CTservice;
import com.OytiePvtLtd.CT.web.dto.CTregistrationDto;

@Controller
@RequestMapping("/registration")

public class CTregistrationController 
{
	private CTservice ctService;
	public CTregistrationController(CTservice ctService)
	{
		super();
		this.setCtService(ctService);		
	}
	@ModelAttribute("class_teacher")
	public CTregistrationDto registrationDto()
	{
		return new CTregistrationDto();
	}
	@GetMapping
	public String showRegistrationForm(Model model)
	{
		model.addAttribute("class_teacher",new CTregistrationDto());
		return "registration";
	}
	@PostMapping
	public String registerUserAccount(@ModelAttribute("class_teacher") CTregistrationDto registrationDto)
	{	
		CTservice.save(registrationDto);
		return "redirect:/registration?success";	
	}
	public CTservice getCtService() {
		return ctService;
	}
	public void setCtService(CTservice ctService) {
		this.ctService = ctService;
	}
	
}
