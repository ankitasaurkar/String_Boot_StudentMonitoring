package com.OytiePvtLtd.CT.service;
import java.util.Arrays;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.OytiePvtLtd.CT.repository.CTrepository;
import com.OytiePvtLtd.CT.web.dto.CTregistrationDto;
import com.OytiePvtLtd.CTLogin.model.CTlogin;
import com.OytiePvtLtd.CTLogin.model.CTregistration;

@Service
@Transactional
public class CTserviceImpl implements CTservice
{
	private CTrepository ctRepository;
	
	public CTserviceImpl(CTrepository ctRepository) 
	{
		super();
		this.ctRepository=ctRepository;	
	}
	
	public CTregistration save(CTregistrationDto registrationDto)
	{
		
		CTregistration class_teacher=new CTregistration(registrationDto.getId(),registrationDto.getEmail(),registrationDto.getFullName(),registrationDto.getNumber(),registrationDto.getQualification(),registrationDto.getClassName(),registrationDto.getSubject(),registrationDto.getAadhar(),registrationDto.getGender(),registrationDto.getDob(),registrationDto.getDoj(),registrationDto.getAddress(),registrationDto.getPassword(),Arrays.asList(new CTlogin("ROLE_USER")));
        return ctRepository.save(class_teacher);
	}

	@Override
	public CTregistration save(CTregistration registrationDto) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
