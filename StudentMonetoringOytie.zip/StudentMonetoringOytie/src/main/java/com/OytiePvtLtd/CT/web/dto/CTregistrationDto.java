package com.OytiePvtLtd.CT.web.dto;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CTregistrationDto
{
	
	private Long id;
	private String email;
	private String fullName;
    private String number;
	private String qualification;
	private String className;
	private String subject;
	private String aadhar;
	private String gender;
	private Date dob;
    private Date doj;
    private String address;
	private String password;
	
	public CTregistrationDto()
	{
		
	}
	
	public CTregistrationDto(Long id, String email, String fullName, String number, String qualification,
			String className, String subject, String aadhar, String gender, Date dob, Date doj, String address,String password) {
		super();
		this.id = id;
		this.email = email;
		this.fullName = fullName;
		this.number = number;
		this.qualification = qualification;
		this.className = className;
		this.subject = subject;
		this.aadhar = aadhar;
		this.gender = gender;
		this.dob = dob;
		this.doj = doj;
		this.address = address;
		this.password = password;
	}
}

