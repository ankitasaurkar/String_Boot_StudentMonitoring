package com.OytiePvtLtd;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StudentMonetoringOytieApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(StudentMonetoringOytieApplication.class, args);
	}

}
