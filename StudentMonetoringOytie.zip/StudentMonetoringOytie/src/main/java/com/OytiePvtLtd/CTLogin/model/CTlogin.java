package com.OytiePvtLtd.CTLogin.model;

import javax.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ctlogin")
@Getter
@Setter
public class CTlogin 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String password;
	
	public CTlogin(String password) 
	{
		super();
		this.password = password;
	}
	
}
