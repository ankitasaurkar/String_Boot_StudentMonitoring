package com.OytiePvtLtd.CTLogin.model;

import java.sql.Date;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter 
@Entity
@Table(name= "class_teacher",uniqueConstraints=@UniqueConstraint(columnNames="id"))

public class CTregistration 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="email")
	private String email;
	@Column(name="fullName")
	private String fullName;
    private String number;
	private String qualification;
	private String className;
	private String subject;
	private String aadhar;
	private String gender;
	private Date dob;
    private Date doj;
    private String address;
	private String password;
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(
			name="users_roles",
			joinColumns= @JoinColumn(
					name="user_id", referencedColumnName="id"),
			inverseJoinColumns= @JoinColumn(
					name="role_id", referencedColumnName="id"))
	private Collection<CTlogin>ctlogin;
	public CTregistration(Long id, String email, String fullName, String integer, String qualification,
			String className, String subject, String integer2, String gender, Date dob, Date doj, String address,String password, Collection<CTlogin> ctlogin) {
		super();
		this.id = id;
		this.email = email;
		this.fullName = fullName;
		this.number = integer;
		this.qualification = qualification;
		this.className = className;
		this.subject = subject;
		this.aadhar = integer2;
		this.gender = gender;
		this.dob = dob;
		this.doj = doj;
		this.address = address;
		this.password = password;
		this.ctlogin = ctlogin;
	}
	
}




