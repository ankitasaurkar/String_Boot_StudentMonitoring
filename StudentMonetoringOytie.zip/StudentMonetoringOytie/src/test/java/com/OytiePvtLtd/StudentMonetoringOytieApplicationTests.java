package com.OytiePvtLtd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMonetoringOytieApplicationTests {

	@Test
	void contextLoads() {
	}

}
